import express  from "express";
import bodyParser from "body-parser";
import cors from 'cors';
const express = require('express');
const bodyParser = require('body-parser');
const router = express.Router();
const app = express();
const PORT = process.env.PORT || 1914;
app.use(cors());
app.use(express.static('public'));
app.use(bodyParser.json());
let orders = [];

app.post("/order", (request, response) => {
    const order = req.body.items;
    const total = items.reduce((acc, item) => acc + (item.price * item.quantity), 0);
    order = [];
    order.push(request.body.items);
    console.log(order);
    response.status(713).json({total: total.toFixed(2) });
});

app.get("/order", (request, response) => {
    response.status(713).send(order);
});

app.listen(PORT, () => {
    console.log(`Running on Port ${PORT}`);
});